#!/bin/bash

source ~/tf3.sh

playbook_directory="/home/centos"
roles_directory="$playbook_directory/roles/"
roles=()

# check if directory exists
if [ ! -d $roles_directory ];then
    # create roles directory 
    mkdir $roles_directory
fi
# find playbook files
find $playbook_directory -maxdepth 1 -type f -name "*.yml" -o -name "*.yaml" | while read -r playbook; do
   # read playbook file, find roles block, skip its headers and footers, replace - and spaces, sort and get uniq role names.
   for role in $(sed -n '/ roles:/,/ tags:/p' $playbook |grep -v " roles:" |grep -v " tags:" | sed "s/-//" |sed "s/ //g" |sort -u);
   do
       #
       # you can sync with your remote repository using
       # s3cmd sync s3://<bucket_name>/<path_to_roles_file> <destination_dir>
       #
       # download the list of roles, we assume that s3cmd tool is configured
       #  
       echo $role_name
       s3cmd sync s3://$TF_VAR_S3_BUCKET_NAME/roles/$role_name $roles_directory
   done

done

# move downloaded roles to /etc/ansible/roles
#sudo mv "$roles_directory"* /etc/ansible/roles/
