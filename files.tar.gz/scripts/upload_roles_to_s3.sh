#!/bin/bash

source ~/tf3.sh

roles_directory="/home/centos/roles/"

# check if directory exists
if [ ! -d $roles_directory ];then
    # create roles directory 
    mkdir -p $roles_directory
fi

#
# upload roles folder to S3 storage to prepare roles be available on s3
# s3cmd sync s3://<bucket_name>/<path_to_roles_file> <destination_dir>
#
s3cmd sync $roles_directory s3://$TF_VAR_S3_BUCKET_NAME/roles/
